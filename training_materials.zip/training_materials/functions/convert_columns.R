col_conversion <- function(col){
  if(!require("forcats")){
    stop("You need to install the `forcats` package from CRAN to use this function", call. = FALSE)
  }
  as_factor(as.character(col))
}