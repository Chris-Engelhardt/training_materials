This repository contains data science training materials for R and serves as an 
example of how you can structure and isolate your projects. 

Please see the individual folders for a description of what should go in them. This information can be viewed by opening the read_me.html file in the top level of the r_training_materials directory.   